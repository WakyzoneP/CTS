package proxy;

public interface ISpital {
    void inregistrareVizita(Vizita vizita);
}
